import { Upload } from './upload.tsx'

export default Upload;