import{j as n}from"./jsx-runtime-D_zvdyIk.js";import{useMDXComponents as o}from"./index-B8rYRX2K.js";import"./index-D4lIrffr.js";function t(s){const e={code:"code",h1:"h1",li:"li",pre:"pre",ul:"ul",...o(),...s.components};return n.jsxs(n.Fragment,{children:[n.jsx(e.h1,{id:"使用reactantd从到1-2封装业务组件库",children:"使用React+Antd从到1-2封装业务组件库"}),`
`,n.jsxs(e.ul,{children:[`
`,n.jsx(e.li,{children:"typescript + react + antd + vite"}),`
`,n.jsx(e.li,{children:"storybook 实现组件测试,组件文档"}),`
`,n.jsx(e.li,{children:"monorepo + pnpm多包管理"}),`
`,n.jsx(e.li,{children:"vitest 单元测试"}),`
`,n.jsx(e.li,{children:"sass预处理"}),`
`,n.jsx(e.li,{children:"husky集成"}),`
`,n.jsx(e.li,{children:"eslint集成"}),`
`]}),`
`,n.jsx(e.pre,{children:n.jsx(e.code,{children:`sykj-ui
├── CHANGELOG.md       
├── README.md
├── build-storybook.log
├── common
├── components
├── coverage
├── css
├── dist
├── es
├── eslint.config.js
├── index.html
├── index.tsx
├── lib
├── package.json
├── pnpm-lock.yaml
├── pnpm-workspace.yaml
├── public
├── scripts
├── storybook-static
├── storybook.log
├── style
├── tree.txt
├── tsconfig.app.json
├── tsconfig.json
├── tsconfig.node.json
├── vite-env.d.ts
`})})]})}function l(s={}){const{wrapper:e}={...o(),...s.components};return e?n.jsx(e,{...s,children:n.jsx(t,{...s})}):t(s)}export{l as default};
