import{j as n}from"./jsx-runtime-D_zvdyIk.js";import{useMDXComponents as m}from"./index-B8rYRX2K.js";import{e as r,f as s}from"./index-DnqAg8Ob.js";import"./index-D4lIrffr.js";import"./iframe-Cn5b3y--.js";import"./index-ChdQiFc1.js";import"./index-DsJinFGm.js";import"./index-CXQShRbs.js";import"./index-DrFu-skq.js";const c=`## [0.0.9](https://gitee.com/sykj-ui/home/compare/v0.0.8...v0.0.9) (2025-04-17)


### Features

* 样式问题 ([227f6ee](https://gitee.com/sykj-ui/home/commits/227f6eef0d6c2cf24f3ad4a2959822f2e7c710b9))



## [0.0.8](https://gitee.com/sykj-ui/home/compare/v0.0.7...v0.0.8) (2025-04-17)


### Features

* 更新打包命令 ([821277c](https://gitee.com/sykj-ui/home/commits/821277c802ca119295bf51ebdaf19093a11f6f6c))



## [0.0.7](https://gitee.com/sykj-ui/home/compare/v0.0.6...v0.0.7) (2025-04-15)



## [0.0.6](https://gitee.com/sykj-ui/home/compare/v0.0.4...v0.0.6) (2025-04-15)



## [0.0.4](https://gitee.com/sykj-ui/home/compare/v0.0.3...v0.0.4) (2025-04-15)



## [0.0.3](https://gitee.com/sykj-ui/home/compare/v0.0.2...v0.0.3) (2025-04-15)



## [0.0.2](https://gitee.com/sykj-ui/home/compare/v0.0.1...v0.0.2) (2025-04-15)



## 0.0.1 (2025-04-15)


### Features

* 基本项目搭建 3b1fd70
* 添加storybook 6e7ad73
* add command 76e65cf
* add init 6b75be9



# 0.0.0 (2025-04-15)\r
\r
\r
### Features\r
\r
* 添加storybook 6e7ad73\r
* add command 76e65cf\r
* add init 6b75be9\r
\r
\r
\r
`;function o(e){const t={h1:"h1",...m(),...e.components};return n.jsxs(n.Fragment,{children:[n.jsx(r,{title:"Changelog"}),`
`,n.jsx(t.h1,{id:"changelog",children:"Changelog"}),`
`,n.jsx(s,{children:c})]})}function v(e={}){const{wrapper:t}={...m(),...e.components};return t?n.jsx(t,{...e,children:n.jsx(o,{...e})}):o(e)}export{v as default};
