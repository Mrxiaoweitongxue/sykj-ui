import { addons } from "@storybook/manager-api";
import theme from "./custTheme.js";

addons.setConfig({
  theme: theme,
});
