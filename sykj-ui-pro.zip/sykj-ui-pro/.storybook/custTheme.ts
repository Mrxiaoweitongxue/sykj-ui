import { create } from "@storybook/theming";

export default create({
  base: "light",
  brandTitle: "SYKJ-UI",
  brandTarget: "_self",
});
