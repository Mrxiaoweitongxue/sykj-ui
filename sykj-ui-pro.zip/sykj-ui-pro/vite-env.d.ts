/// <reference types="vite/client" />

declare module '*.scss' { }

