## [0.0.1](https://gitee.com/sykj-ui/home/compare/scripts@1.1.5...scripts@0.0.1) (2025-04-15)



## 1.1.5 (2025-04-15)



## 0.0.1 (2025-04-15)



## [1.1.4](https://github.com/vexip-ui/vexip-ui/compare/scripts@1.1.3...scripts@1.1.4) (2024-02-01)


### 🐞 Bug Fixes

* **scripts:** support specify path of ending with package.json ([ebe2f09](https://github.com/vexip-ui/vexip-ui/commit/ebe2f099f9d48a4837b95ee201e084b6e78c44a2))



## [1.1.3](https://github.com/vexip-ui/vexip-ui/compare/scripts@1.1.2...scripts@1.1.3) (2023-12-14)


### 🐞 Bug Fixes

* **scripts:** incorrect bin file name ([1787579](https://github.com/vexip-ui/vexip-ui/commit/178757942b3da009946e479c6d9ce8c3e36d5e46))



## [1.1.2](https://github.com/vexip-ui/vexip-ui/compare/scripts@1.1.1...scripts@1.1.2) (2023-11-24)



## [1.1.1](https://github.com/vexip-ui/vexip-ui/compare/scripts@1.1.0...scripts@1.1.1) (2023-11-03)


### 🐞 Bug Fixes

* **config:** force vxp namespace for css variables ([814fd2c](https://github.com/vexip-ui/vexip-ui/commit/814fd2caaada47b3e7053ec69673b4b6bc881dd8))



# [1.1.0](https://github.com/vexip-ui/vexip-ui/compare/scripts@1.0.0...scripts@1.1.0) (2023-11-02)


### ✨ Features

* **cli:** support generate types.d.ts with custom prefix ([982ac80](https://github.com/vexip-ui/vexip-ui/commit/982ac80767350aca4eadfa413b1186c4fb01a43e))



# 1.0.0 (2023-10-31)



