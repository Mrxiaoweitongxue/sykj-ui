# @vexip-ui/utils

This package provides common utils for vexip-ui components, it is published as a package that can be used standalone.

## Install

```sh
pnpm i @vexip-ui/utils
```
