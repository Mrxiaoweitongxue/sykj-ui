module.exports = {
  extends: ['stylelint-config-standard', 'stylelint-config-prettier'],
};
