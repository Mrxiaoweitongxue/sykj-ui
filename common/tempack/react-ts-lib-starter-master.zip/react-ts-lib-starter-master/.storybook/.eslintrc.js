module.exports = {
  rules: {
    'import/no-extraneous-dependencies': 'off',
  },
};
